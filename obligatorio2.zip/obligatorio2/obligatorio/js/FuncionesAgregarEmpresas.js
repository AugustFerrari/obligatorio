window.addEventListener("load", inicio2);

let miCasaa = new Casaa("Avda 18 de Julio 1234");
let empresanumero = 1;

function inicio2() {
    document.getElementById("botonAgregar2").addEventListener("click", agregarEmpresa);
    document.getElementById("creciente").addEventListener("click", ordenarEmpresasCreciente);
    document.getElementById("decreciente").addEventListener("click", ordenarEmpresasDecreciente);
}


function agregarEmpresa() {
    let miForm = document.getElementById("formempresa");
    let nombre2 = document.getElementById("nombre2").value;
    let direccion = document.getElementById("direccion").value;
    let rubro = document.getElementById("rubro").value;
    let reclamos = 0;

    if (nombre2 === "" || direccion === "" || rubro === "" ) {
      alert("No puedes ingresar campos vacios!");
    } else {
      if (miCasaa.listaEmpresa.find(empresa => empresa.nombre2 === nombre2)) {
        alert("Ya hay una empresa con este nombre");
      }
      else {
        let unEmpresa = new Empresa(nombre2, direccion, rubro, reclamos);
        miCasaa.agregarEmpresa(unEmpresa);
        alert("¡Agregado!");
        limpiarPantalla2();
        botnonesFiltrado();
        mostrarTabla(); 
        estadistica();
        empresanumero++;
      }
    }   
}

function limpiarPantalla2() {
  document.getElementById("formEmpresa").reset();
}

function ordenarEmpresasCreciente() {
  miCasaa.listaEmpresa.sort((a, b) => a.nombre2.localeCompare(b.nombre2));
  mostrarTabla();
}

function ordenarEmpresasDecreciente() {
  miCasaa.listaEmpresa.reverse((a, b) => b.nombre2.localeCompare(a.nombre2));
  mostrarTabla();
}

function botnonesFiltrado(){
  let contenedorFiltros = document.getElementById("contenedorFiltros");
  contenedorFiltros.innerHTML = "";

  let iniciales = [];
  for (let empresa of miCasaa.listaEmpresa) {
    let inicial = empresa.nombre2.charAt(0).toUpperCase();
    if (!iniciales.includes(inicial)) {
      iniciales.push(inicial);
    }
  }

  for (let inicial of iniciales) {
    let boton = document.createElement("button");
    boton.innerHTML = inicial;
    contenedorFiltros.appendChild(boton);
  }

  let botontotal = document.createElement("button");
  botontotal.innerHTML = "*";
  contenedorFiltros.appendChild(botontotal);
}

function mostrarTabla() {
    let listaQuejas = miCasa.darQuejas();
    let listaEmpresa = miCasaa.darEmpresa();
    let tabla = document.getElementById("tablaG");
    tabla.innerHTML = "";
  
    // Agregar clases a la tabla y al contenedor
    tabla.classList.add("tabla");
    tabla.parentElement.classList.add("estadistica");
  
    let tablaElement = document.createElement("table");
    
    let caption = tablaElement.createCaption();
    caption.classList.add("titulotabla");
    caption.innerHTML = "Empresas que empiezan con T";
    let header = tablaElement.createTHead();
    let row = header.insertRow();
    let cellD = row.insertCell();
    cellD.innerHTML = "Nombre";
    let cellDe = row.insertCell();
    cellDe.innerHTML = "Dirección";
    let cellM = row.insertCell();
    cellM.innerHTML = "Rubro";
    let cellR = row.insertCell();
    cellR.innerHTML = "Reclamos";
    
  
    for (let i = 0; i < listaEmpresa.length; i++) {
      let fila = tablaElement.insertRow();
      let empresa = listaEmpresa[i];
      for (let k in empresa) {
        let celda = fila.insertCell();
        celda.innerHTML = empresa[k];
      }
    }

    tabla.appendChild(tablaElement);
  }
function OrdenarCreciente() {
    let crecient= listaEmpresa.sort();

}
function ValidarEmpresas() {
  
    if (!miCasaa.hayEmpresa()) {
        alert("Debes ingresar empresas primero");
        return;
    }else {
      
      verReclamos();
    
    }
}

function ValidarEmpresasBoton() {
  
  if (!miCasaa.hayEmpresa()) {
      alert("Debes ingresar empresas primero");
      return;
  }else{

    agregarReclamo();
    
    }
  }

function estadistica(){
    let contenedorinfo = document.getElementById("contadorE");
    contenedorinfo.innerHTML = "";
    contenedorinfo.classList.add("informacion");
    
    let h3 = document.createElement("h3");
    h3.innerHTML = "Información general";
    contenedorinfo.appendChild(h3);

    let promedio = document.createElement("p");
    promedio.innerHTML = "El promedio de las cantidades considerando todos los reclamos de las empresas es: 4";
    contenedorinfo.appendChild(promedio);

    let contadorempresa = document.createElement("p");
    contadorempresa.innerHTML = "Total de empresas registradas: " + empresanumero;
    contenedorinfo.appendChild(contadorempresa);

    let h3empresa = document.createElement("h3");
    h3empresa.innerHTML = "Empresas sin Reclamos";
    contenedorinfo.appendChild(h3empresa);

    let ul1 = document.createElement("ul");

    let li1 = document.createElement("li");
    li1.innerHTML = "Alfa (18 de julio 12345) Rubro: Muebles";
    ul1.appendChild(li1);

    contenedorinfo.appendChild(ul1);

    let h3empresa2 = document.createElement("h3");
    h3empresa2.innerHTML = "Rubros con maxima cantidad de reclamos";
    contenedorinfo.appendChild(h3empresa2);

    let ul2 = document.createElement("ul");

    let li2 = document.createElement("li");
    li2.innerHTML = "Viajes: cantidad 4";
    ul2.appendChild(li2);

    contenedorinfo.appendChild(ul2);


}