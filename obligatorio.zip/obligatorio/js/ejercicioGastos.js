window.addEventListener("load", inicio);

let miCasa = new Casa("Avda 18 de Julio 1234");
let contadorQuejas = 0; 

function inicio() {
  document.getElementById("botonAgregar").addEventListener("click", agregarQueja);
}

function agregarQueja() {
  let miForm = document.getElementById("formAgregar");

  let nombre = document.getElementById("nombre").value;
  let empresa = document.getElementById("empresa").value;
  let reclamo = document.getElementById("reclamo").value;
  let reclamotxt = document.getElementById("reclamotxt").value;

  let unaQueja = new Queja(nombre, empresa, reclamo, reclamotxt);
  miCasa.agregarQueja(unaQueja);
  alert("Agregado!");
  limpiarPantalla();
  mostrarBox();
}

function limpiarPantalla() {
  let container = document.getElementById("listado");
  container.innerHTML = "";
}

function mostrarBox() {
  let container = document.getElementById("listado");
  container.innerHTML = "";

  let listaQuejas = miCasa.darQuejas();

  for (let i = listaQuejas.length - 1; i >= 0; i--) {
    let queja = listaQuejas[i];
    let section = document.createElement("section");
    section.classList.add("contador");

    let h3 = document.createElement("h3");
    h3.innerHTML = "Reclamo No. " + (i + 1);
    section.appendChild(h3);

    let div = document.createElement("div");
    div.classList.add("cajareclamo");
    section.appendChild(div);

    let p = document.createElement("p");
    p.innerHTML = queja.nombre + ":";
    p.classList.add("texto");
    div.appendChild(p);

    let p2 = document.createElement("p");
    p2.innerHTML = "Empresa: " + queja.empresa;
    p2.classList.add("texto");
    div.appendChild(p2);

    let p3 = document.createElement("p");
    p3.innerHTML = queja.reclamotxt;
    p3.classList.add("texto");
    div.appendChild(p3);

    let divContador = document.createElement("div");
    divContador.classList.add("unidor");

    let button = document.createElement("button");
    button.innerHTML = "¡A mí también me pasó!";
    divContador.appendChild(button);

    let contador = document.createElement("p");
    contador.innerHTML = "Contador: ";
    divContador.appendChild(contador);

    div.appendChild(divContador);

    container.appendChild(section);
  }
}