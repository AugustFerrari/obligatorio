window.addEventListener("load", inicio);

let miSistema = new Sistema();
let miCasa = new Casa("Avda 18 de Julio 1234");
let contadorReclamos = 0;

function inicio() {
  document.getElementById("botonAgregar").addEventListener("click", agregarQueja);
  document.getElementById("botonReclamo").addEventListener("click", selectorEmpresa);
  document.getElementById("botonAgregar").addEventListener("click",mostrarTabla);
  document.getElementById("botonAgregar2").addEventListener("click", agregarEmpresa);
  document.getElementById("creciente").addEventListener("click", ordenarEmpresasCreciente);
  document.getElementById("decreciente").addEventListener("click", ordenarEmpresasDecreciente);
  document.getElementById("envio").addEventListener("click", filtroBuscador);
}

function agregarQueja() {
  let miForm = document.getElementById("formAgregar");

  let nombre = document.getElementById("nombre").value;
  let empresa = document.getElementById("empresaSel").value;
  let reclamo = document.getElementById("reclamo").value;
  let reclamotxt = document.getElementById("reclamotxt").value;

  if (nombre === "" || empresa === "" || reclamo === "" || reclamotxt === "") {
    alert("No puedes ingresar campos vacios!");
  } else {
    let unaQueja = new Queja(nombre, empresa, reclamo, reclamotxt);
    
    contadorReclamos =  miSistema.darEmpresa();
    console.log(contadorReclamos);
    miCasa.agregarQueja(unaQueja);
    alert("Agregado!");
    limpiarPantalla();
    mostrarBox();
    estadistica()
  }
  
}

function agregarEmpresa() {
   
  let nombre2 = document.getElementById("nombre2").value;
  let direccion = document.getElementById("direccion").value;
  let rubro = document.getElementById("rubro").value;
  let reclamos = 0;

  if (nombre2 === "" || direccion === "" || rubro === "" ) {
    alert("No puedes ingresar campos vacios!");
  } else {
    if (miSistema.listaEmpresa.find(empresa => empresa.nombre2 === nombre2)) {
      alert("Ya hay una empresa con este nombre");
    }
    else {
      let unEmpresa = new Empresa(nombre2, direccion, rubro, reclamos);
      miSistema.agregarEmpresa(unEmpresa);
      alert("¡Agregado!");
      limpiarPantalla2();
      botonesFiltrado();
      mostrarTabla();
      estadistica();
    }
  }   
}

function limpiarPantalla() {
  document.getElementById("formAgregar").reset();
}


function limpiarPantalla2() {
  document.getElementById("formEmpresa").reset();
}


function ordenarEmpresasCreciente() {
  miSistema.listaEmpresa.sort((a, b) => a.nombre2.localeCompare(b.nombre2));
  mostrarTabla();
}

function ordenarEmpresasDecreciente() {
  miSistema.listaEmpresa.reverse((a, b) => b.nombre2.localeCompare(a.nombre2));
  mostrarTabla();
}

function botonesFiltrado() {
  let contenedorFiltros = document.getElementById("contenedorFiltros");
  contenedorFiltros.innerHTML = "";

  let iniciales = [];
  for (let empresa of miSistema.listaEmpresa) {
    let inicial = empresa.nombre2.charAt(0).toUpperCase();
    if (!iniciales.includes(inicial)) {
      iniciales.push(inicial);
    }
  }

  for (let inicial of iniciales) {
    let boton = document.createElement("button");
    boton.innerHTML = inicial;
    boton.addEventListener("click", () => filtroPorLetra(inicial));
    contenedorFiltros.appendChild(boton);
  }

  let botontotal = document.createElement("button");
  botontotal.innerHTML = "*";
  botontotal.addEventListener("click", () => mostrarTabla()); // Mostrar todas las empresas
  contenedorFiltros.appendChild(botontotal);
}

function filtroPorLetra(letra) {
  const tablaEstadisticas = document.getElementById('tablaG');

  const filas = tablaEstadisticas.getElementsByTagName('tr');
  for (let i = 0; i < filas.length; i++) {
    const celdaNombre = filas[i].getElementsByTagName('td')[0];

    const textoCelda = celdaNombre.textContent.toLowerCase();
    const filaCoincide = textoCelda.startsWith(letra.toLowerCase());

    filas[i].style.display = filaCoincide ? '' : 'none';
  }

  const caption = tablaEstadisticas.querySelector('caption');
  caption.innerHTML = "Empresas que empiezan con " + letra;
}

function filtroBuscador() {
  const filtro = document.getElementById('letraFiltro');
  const tablaEstadisticas = document.getElementById('listado');

  const busqueda = filtro.value.toLowerCase();

  const secciones = tablaEstadisticas.getElementsByTagName('section');
  for (let i = 0; i < secciones.length; i++) {
    const nombreElement = secciones[i].querySelector('p.texto');

    const textoNombre = nombreElement.textContent.toLowerCase();
    const seccionCoincide = textoNombre.includes(busqueda);

    secciones[i].style.display = seccionCoincide ? '' : 'none';
  }
}

function mostrarBox() {

  let container = document.getElementById("listado");
  container.innerHTML = "";

  let listaQuejas = miCasa.darQuejas();

  for (let i = listaQuejas.length - 1; i >= 0; i--) {
    let queja = listaQuejas[i];
    let section = document.createElement("section");
    section.classList.add("contador");
    
    let h3 = document.createElement("h3");
    h3.innerHTML = "Reclamo No. " + (i + 1);
    section.appendChild(h3);

    let div = document.createElement("div");
    div.classList.add("cajareclamo");
    section.appendChild(div);

  
    let p = document.createElement("p");
    p.innerHTML = queja.nombre + ":";
    p.classList.add("texto");

    let cite = document.createElement("cite");
    cite.innerHTML = queja.reclamo;
    cite.classList.add("color1");
    p.appendChild(cite);

    div.appendChild(p); 

    let p2 = document.createElement("p");
    p2.innerHTML = "Empresa:";
    p2.classList.add("texto");

    let cite2 = document.createElement("cite");
    cite2.innerHTML = queja.empresa;
    cite2.classList.add("color2");
    p2.appendChild(cite2);

    div.appendChild(p2); 

    let p3 = document.createElement("p");
    p3.innerHTML = queja.reclamotxt;
    p3.classList.add("texto");
    div.appendChild(p3);

    let divContador = document.createElement("div");
    divContador.classList.add("unidor");

    let button = document.createElement("button");
    button.innerHTML = "¡A mí también me pasó!";
    divContador.appendChild(button);

    let contador = document.createElement("p");
    contador.classList.add("mostrador");
    contador.innerHTML = "Contador: 0";
    divContador.appendChild(contador);

    div.appendChild(divContador);

    container.appendChild(section);

    function ContadorNum() {
      let bot = button;
      let mostrador = contador;
      let contadorReclamos=0;
      bot.onclick = function () {
        contadorReclamos++;
        
        
        mostrador.innerHTML = "Contador: " + contadorReclamos;
        

        mostrarTabla();
        return contadorReclamos;
      };
      console.log(contadorReclamos);
    }
    ContadorNum();
  }
}

let listaEmpresa= miSistema.darEmpresa(); 
function selectorEmpresa(){
  let contenedor = document.getElementById("empresaSel");
  contenedor.innerHTML = "";
  

  for (let i = 0; i < listaEmpresa.length; i++) {
    let empresa = listaEmpresa[i];
    let option = document.createElement("option");
    option.innerHTML = empresa["nombre2"]

    contenedor.appendChild(option);
  }
}

function mostrarTabla() {
  let listaEmpresa = miSistema.darEmpresa();
  let listaQuejas = miCasa.darQuejas();
  let tabla = document.getElementById("tablaG");
  tabla.innerHTML = "";

  tabla.classList.add("tabla");
  tabla.parentElement.classList.add("estadistica");

  let tablaElement = document.createElement("table");

  let caption = tablaElement.createCaption();
  caption.classList.add("titulotabla");
  caption.innerHTML = "Empresas: Todas";

  let header = tablaElement.createTHead();
  let row = header.insertRow();
  let cellD = row.insertCell();
  cellD.innerHTML = "Nombre";
  let cellDe = row.insertCell();
  cellDe.innerHTML = "Dirección";
  let cellM = row.insertCell();
  cellM.innerHTML = "Rubro";
  let cellR = row.insertCell();
  cellR.innerHTML = "Reclamos";

  for (let i = 0; i < listaEmpresa.length; i++) {
    let fila = tablaElement.insertRow();
    let empresa = listaEmpresa[i];
    
    let celdaNombre = fila.insertCell();
    celdaNombre.innerHTML = empresa.nombre2;
    let celdaDireccion = fila.insertCell();
    celdaDireccion.innerHTML = empresa.direccion;
    let celdaRubro = fila.insertCell();
    celdaRubro.innerHTML = empresa.rubro;

    let reclamos = contadorReclamos; 

    let celdaReclamos = fila.insertCell();
    celdaReclamos.innerHTML = reclamos;
  }

  tabla.appendChild(tablaElement);
}
function contarReclamos(listaQuejas, nombreEmpresa) {
  let reclamos = 0;

  for (let j = 0; j < listaQuejas.length; j++) {
    let queja = listaQuejas[j];
    if (queja.empresa === nombreEmpresa) {
      reclamos++;
      
    }
  }

  return reclamos;
}

function ValidarEmpresas() {
  
    if (!miSistema.hayEmpresa()) {
        alert("Debes ingresar empresas primero");
        return;
    }else {
      
      verReclamos();
    
    }
}

function ValidarEmpresasBoton() {
  
  if (!miSistema.hayEmpresa()) {
      alert("Debes ingresar empresas primero");
      return;
  }else{

    agregarReclamo();
    mostrarTabla();
    estadistica();
    }
  }

function estadistica(){
    let contenedorinfo = document.getElementById("contadorE");
    contenedorinfo.innerHTML = "";
    contenedorinfo.classList.add("informacion");
    
    let h3 = document.createElement("h3");
    h3.innerHTML = "Información general";
    contenedorinfo.appendChild(h3);


    let totalReclamos = contadorReclamos;

    for (let i = 0; i < miSistema.listaEmpresa.length; i++) {
      let empresa = miSistema.listaEmpresa[i];
      let reclamos = contarReclamos(miCasa.darQuejas(), empresa.nombre2);
      totalReclamos += reclamos;
    }

    let promedio = document.createElement("p");
    promedio.innerHTML = "El promedio de las cantidades considerando todos los reclamos de las empresas es: " + totalReclamos/miSistema.darEmpresa().length;
    contenedorinfo.appendChild(promedio);

    let contadorempresa = document.createElement("p");
    let empresanumero = miSistema.darEmpresa().length;
    contadorempresa.innerHTML = "Total de empresas registradas: " + empresanumero;
    contenedorinfo.appendChild(contadorempresa);


    let h3empresa = document.createElement("h3");
    h3empresa.innerHTML = "Empresas sin Reclamos";
    contenedorinfo.appendChild(h3empresa);
    

    let ulSinReclamos = document.createElement("ul");

    let empresasSinReclamos = miSistema.listaEmpresa.filter(
      (empresa) => contarReclamos(miCasa.darQuejas(), empresa.nombre2) === 0);
  
    if (empresasSinReclamos.length === 0) {
      let li = document.createElement("li");
      li.innerHTML = "Todas las empresas tienen reclamos";
      ulSinReclamos.appendChild(li);
    } else {
      for (let empresa of empresasSinReclamos) {
        let li = document.createElement("li");
        li.innerHTML = empresa.nombre2 + " " + "(" + empresa.direccion + ")" + " " +  "Rubro " + empresa.rubro;
        ulSinReclamos.appendChild(li);
      }
    }
  
    contenedorinfo.appendChild(ulSinReclamos);

    let h3empresa2 = document.createElement("h3");
    h3empresa2.innerHTML = "Rubros con maxima cantidad de reclamos";
    contenedorinfo.appendChild(h3empresa2);

    let ul2 = document.createElement("ul");

    let listaEmpresa = miSistema.darEmpresa();
    let listaQuejas = miCasa.darQuejas();

    let maxReclamos = 0;
    let empresaMasReclamos = null;

    for (let empresa of listaEmpresa) {
      let reclamos = contarReclamos(listaQuejas, empresa.nombre2);
      if (reclamos > maxReclamos) {
        maxReclamos = reclamos;
        empresaMasReclamos = empresa;
      }
    }

    if (empresaMasReclamos) {
      let li2 = document.createElement("li");
      li2.innerHTML = `${empresaMasReclamos.nombre2}: cantidad ${maxReclamos}`;
      ul2.appendChild(li2);
    }

    contenedorinfo.appendChild(ul2);
}