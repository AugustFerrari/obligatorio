class Casa {
constructor(elReclamo) {
	this.reclamo = elReclamo;
	this.listaQuejas = [];
}

agregarQueja(unQueja) {
	this.listaQuejas.push(unQueja);
}

darQuejas() {
	return this.listaQuejas;
}

hayQuejas() {
	return this.listaQuejas.length > 0;
}

toString() {
	return this.reclamo;
}

ordenar(ordenadoCrec) {
	if (ordenadoCrec) {
	// Ordenar en forma creciente
	return this.darQuejas().sort(function (primero, segundo) {
		return primero.reclamo - segundo.reclamo;
	});
	} else {
	// Ordenar en forma decreciente utilizando arrow function
	return this.darQuejas().sort((primero, segundo) => {
		return segundo.reclamo - primero.reclamo;
	});
	}
}
}

class Queja {
	constructor(elNombre, laEmpresa, elReclamo, elReclamotxt) {
		this.nombre = elNombre;
		this.empresa = laEmpresa;
		this.reclamo = elReclamo;
		this.reclamotxt = elReclamotxt;
	}
}

class Sistema{
    constructor(laDireccion) {
        this.direccion = laDireccion;
        this.listaEmpresa = [];
        this.EmpresasSinQuejas=[];
    }
    
    agregarEmpresa(unEmpresa) {
        this.listaEmpresa.push(unEmpresa);
    }
    agregarEmpresaSinQuejas(empresa){
        this.EmpresasSinQuejas.push(empresa)
    }
    
    darEmpresa() {
        return this.listaEmpresa;
    }
    darEmpresaSinQuejas(){
        return this.EmpresasSinQuejas;
    }
    
    hayEmpresa() {
        return this.listaEmpresa.length > 0;
    }
    
    toString() {
        return this.direccion;
    }
}

class Empresa {
    constructor(elnombre2, laDireccion, elRubro) {
        this.nombre2 = elnombre2;
        this.direccion = laDireccion;
        this.rubro = elRubro;
        this.reclamos = 0;
    }
}