window.addEventListener("load", inicio2);

let miSistema = new Sistema();

function inicio2() {
    document.getElementById("botonAgregar2").addEventListener("click", agregarEmpresa);
    document.getElementById("creciente").addEventListener("click", ordenarEmpresasCreciente);
    document.getElementById("decreciente").addEventListener("click", ordenarEmpresasDecreciente);
    document.getElementById("envio").addEventListener("click", filtroBuscador);
}


function agregarEmpresa() {
   
    let nombre2 = document.getElementById("nombre2").value;
    let direccion = document.getElementById("direccion").value;
    let rubro = document.getElementById("rubro").value;

    if (nombre2 === "" || direccion === "" || rubro === "" ) {
      alert("No puedes ingresar campos vacios!");
    } else {
      if (miSistema.listaEmpresa.find(empresa => empresa.nombre2 === nombre2)) {
        alert("Ya hay una empresa con este nombre");
      }
      else {
        let unEmpresa = new Empresa(nombre2, direccion, rubro);
        miSistema.agregarEmpresa(unEmpresa);
        alert("¡Agregado!");
        limpiarPantalla2();
        botonesFiltrado();
        mostrarTabla();
        estadistica();
      }
    }   
}

function limpiarPantalla2() {
  document.getElementById("formEmpresa").reset();
}

function ordenarEmpresasCreciente() {
  miSistema.listaEmpresa.sort((a, b) => a.nombre2.localeCompare(b.nombre2));
  mostrarTabla();
}

function ordenarEmpresasDecreciente() {
  miSistema.listaEmpresa.reverse((a, b) => b.nombre2.localeCompare(a.nombre2));
  mostrarTabla();
}

function botonesFiltrado() {
  let contenedorFiltros = document.getElementById("contenedorFiltros");
  contenedorFiltros.innerHTML = "";

  let iniciales = [];
  for (let empresa of miSistema.listaEmpresa) {
    let inicial = empresa.nombre2.charAt(0).toUpperCase();
    if (!iniciales.includes(inicial)) {
      iniciales.push(inicial);
    }
  }

  for (let inicial of iniciales) {
    let boton = document.createElement("button");
    boton.innerHTML = inicial;
    boton.addEventListener("click", () => filtroPorLetra(inicial));
    contenedorFiltros.appendChild(boton);
  }

  let botontotal = document.createElement("button");
  botontotal.innerHTML = "*";
  botontotal.addEventListener("click", () => mostrarTabla()); // Mostrar todas las empresas
  contenedorFiltros.appendChild(botontotal);
}

function filtroPorLetra(letra) {
  const tablaEstadisticas = document.getElementById('tablaG');

  const filas = tablaEstadisticas.getElementsByTagName('tr');
  for (let i = 0; i < filas.length; i++) {
    const celdaNombre = filas[i].getElementsByTagName('td')[0];

    const textoCelda = celdaNombre.textContent.toLowerCase();
    const filaCoincide = textoCelda.startsWith(letra.toLowerCase());

    filas[i].style.display = filaCoincide ? '' : 'none';
  }

  const caption = tablaEstadisticas.querySelector('caption');
  caption.innerHTML = "Empresas que empiezan con " + letra;
}


function mostrarTabla(totalReclamosPersonales) {
  let listaEmpresa = miSistema.darEmpresa();
  let listaQuejas = miCasa.darQuejas();
  let tabla = document.getElementById("tablaG");
  tabla.innerHTML = "";

  tabla.classList.add("tabla");
  tabla.parentElement.classList.add("estadistica");

  let tablaElement = document.createElement("table");

  let caption = tablaElement.createCaption();
  caption.classList.add("titulotabla");
  caption.innerHTML = "Empresas: Todas";

  let header = tablaElement.createTHead();
  let row = header.insertRow();
  let cellD = row.insertCell();
  cellD.innerHTML = "Nombre";
  let cellDe = row.insertCell();
  cellDe.innerHTML = "Dirección";
  let cellM = row.insertCell();
  cellM.innerHTML = "Rubro";
  let cellR = row.insertCell();
  cellR.innerHTML = "Reclamos";

  for (let i = 0; i < listaEmpresa.length; i++) {
    let fila = tablaElement.insertRow();
    let empresa = listaEmpresa[i];
    
    let celdaNombre = fila.insertCell();
    celdaNombre.innerHTML = empresa.nombre2;
    let celdaDireccion = fila.insertCell();
    celdaDireccion.innerHTML = empresa.direccion;
    let celdaRubro = fila.insertCell();
    celdaRubro.innerHTML = empresa.rubro;

    let reclamos = contarReclamos(listaQuejas, empresa.nombre2); 

    let celdaReclamos = fila.insertCell();
    celdaReclamos.innerHTML = reclamos;
  }

  tabla.appendChild(tablaElement);
}

function contarReclamos(listaQuejas, nombreEmpresa) {
  let reclamos = 0;

  for (let j = 0; j < listaQuejas.length; j++) {
    let queja = listaQuejas[j];
    if (queja.empresa === nombreEmpresa) {
      reclamos = totalReclamosPersonales + reclamos++;
    }
  }

  return reclamos;
}

function ValidarEmpresas() {
  
    if (!miSistema.hayEmpresa()) {
        alert("Debes ingresar empresas primero");
        return;
    }else {
      
      verReclamos();
    
    }
}

function ValidarEmpresasBoton() {
  
  if (!miSistema.hayEmpresa()) {
      alert("Debes ingresar empresas primero");
      return;
  }else{

    agregarReclamo();
    mostrarTabla();
    estadistica();
    }
  }

function estadistica(){
    let contenedorinfo = document.getElementById("contadorE");
    contenedorinfo.innerHTML = "";
    contenedorinfo.classList.add("informacion");
    
    let h3 = document.createElement("h3");
    h3.innerHTML = "Información general";
    contenedorinfo.appendChild(h3);


    let totalReclamos = contadorReclamos;

    for (let i = 0; i < miSistema.listaEmpresa.length; i++) {
      let empresa = miSistema.listaEmpresa[i];
      let reclamos = contarReclamos(miCasa.darQuejas(), empresa.nombre2);
      totalReclamos += reclamos;
    }

    let promedio = document.createElement("p");
    promedio.innerHTML = "El promedio de las cantidades considerando todos los reclamos de las empresas es: " + totalReclamos/miSistema.darEmpresa().length;
    contenedorinfo.appendChild(promedio);

    let contadorempresa = document.createElement("p");
    let empresanumero = miSistema.darEmpresa().length;
    contadorempresa.innerHTML = "Total de empresas registradas: " + empresanumero;
    contenedorinfo.appendChild(contadorempresa);


    let h3empresa = document.createElement("h3");
    h3empresa.innerHTML = "Empresas sin Reclamos";
    contenedorinfo.appendChild(h3empresa);
    

    let ulSinReclamos = document.createElement("ul");

    let empresasSinReclamos = miSistema.listaEmpresa.filter(
      (empresa) => contarReclamos(miCasa.darQuejas(), empresa.nombre2) === 0);
  
    if (empresasSinReclamos.length === 0) {
      let li = document.createElement("li");
      li.innerHTML = "Todas las empresas tienen reclamos";
      ulSinReclamos.appendChild(li);
    } else {
      for (let empresa of empresasSinReclamos) {
        let li = document.createElement("li");
        li.innerHTML = empresa.nombre2 + " " + "(" + empresa.direccion + ")" + " " +  "Rubro " + empresa.rubro;
        ulSinReclamos.appendChild(li);
      }
    }
  
    contenedorinfo.appendChild(ulSinReclamos);

    let h3empresa2 = document.createElement("h3");
    h3empresa2.innerHTML = "Rubros con maxima cantidad de reclamos";
    contenedorinfo.appendChild(h3empresa2);

    let ul2 = document.createElement("ul");

    let listaEmpresa = miSistema.darEmpresa();
    let listaQuejas = miCasa.darQuejas();

    let maxReclamos = 0;
    let empresaMasReclamos = null;

    for (let empresa of listaEmpresa) {
      let reclamos = contarReclamos(listaQuejas, empresa.nombre2);
      if (reclamos > maxReclamos) {
        maxReclamos = reclamos;
        empresaMasReclamos = empresa;
      }
    }

    if (empresaMasReclamos) {
      let li2 = document.createElement("li");
      li2.innerHTML = `${empresaMasReclamos.nombre2}: cantidad ${maxReclamos}`;
      ul2.appendChild(li2);
    }

    contenedorinfo.appendChild(ul2);
}
